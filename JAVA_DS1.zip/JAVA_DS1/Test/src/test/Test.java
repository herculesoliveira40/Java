/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Your
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
       int num1 = 11;
       int num2 = 5;
                
                
      System.out.println(num1+num2 + " IMC é:" + (num1+num2));     
        
    }
    
}
