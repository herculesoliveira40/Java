/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeiroprograma;

import java.util.Date;

/**
 *
 * @author Your
 */
public class PrimeiroPrograma {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        System.out.println("Ola Mundo JAVAAAAAAAAAAAAA");
        
        Date tempo = new Date();
        
        System.out.println("A data e hora é:");
        System.out.println(tempo.toString());
    }
    
}
